# Luckee editorial case study

This folder is ready for GitHub Pages.

1. Upload every file and folder in this directory to a GitHub repository.
2. Open Settings, then Pages.
3. Publish from the repository root on the selected branch.

Keep the `case-detail-assets` directory beside `index.html`. The page uses a local forest WebP image, SVG logo and WOFF2 fonts, so GitHub Pages can load the complete design without files from this computer.

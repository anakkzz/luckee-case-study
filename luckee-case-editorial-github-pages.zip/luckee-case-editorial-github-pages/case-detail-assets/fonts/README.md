# Local web fonts

This case-study preview self-hosts two Latin WOFF2 font files:

- `instrument-serif-regular-latin.woff2` — Instrument Serif Regular
- `montserrat-latin.woff2` — Montserrat variable weight range used at 400–700

Both font families are distributed under the SIL Open Font License 1.1. The corresponding license texts are kept in this directory.

Sources:

- Instrument Serif: https://github.com/google/fonts/tree/main/ofl/instrumentserif
- Montserrat: https://github.com/google/fonts/tree/main/ofl/montserrat
- WOFF2 delivery files: https://fonts.gstatic.com/

Downloaded on 2026-09-04. These files cover the Latin character set used by the English case-study page.
